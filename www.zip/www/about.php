<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: Harry
 * Date: 25/05/2019
 * Time: 18:26
 */

require 'menu.php';
require 'login.php';
require 'userSession.php';
?>

<!--
This pages purpose is to display the contact details for the central scotland college. This inlcudes their contact number, phone number and address.
-->

    <html>
    <head>
        <title>About</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/menu.css">
        <link rel="stylesheet" type="text/css" href="css/responsive.css">

        <script type="text/javascript">
            function displayError(msg) {
                alert("Problem signing in: "+msg);
            }
        </script>
        <script src="js/menu.js" type="text/javascript"></script>

        <meta charset="UTF-8">
        <meta name="description" content="Central Scotland College's about page.">
        <meta name="keywords" content="Central Scotland College, About, Contact Details">
        <meta name="author" content="Harry Beggs">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
    <div id="header">
        <img src="img/logo.jpg" id="logo">
        <h1>About</h1>
        <?php displayLogin();?>
</div>
    <?php displayMenu(ABOUT);?>
<div id="content">
    <h2>Central Scotland College</h2>
    <p>
       Central Scotland College's purpose is to provide an exceptional learning ground for our students to hone their skills. Our students work efficiently and effectively and leave our college prepared for the work place environment.
        <br>
        Phone: +44 7700 900023
        <br>
        Address: Grangemouth Rd, Falkirk FK2 9AD
    </p>
</div>
</body>
</html>