<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: Harry
 * Date: 25/05/2019
 * Time: 18:26
 */

require 'menu.php';
require 'login.php';
require 'userSession.php';
?>
<!--
This pages purpose is to eitther change the users password or delete their account. It will validate new passwords and only change them if appropriate.
-->
<html>
<head>
    <title>My Profile</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/menu.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

    <script type="text/javascript">
        function displayError(msg) {
            alert("Problem signing in: "+msg);
        }
    </script>
    <script src="js/menu.js" type="text/javascript"></script>


    <meta charset="UTF-8">
    <meta name="description" content="Central Scotland College's about page.">
    <meta name="keywords" content="Central Scotland College, Profile, Delete Details">
    <meta name="author" content="Harry Beggs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="header">
    <img src="img/logo.jpg" id="logo">
    <h1>Profile</h1>
    <?php displayLogin();?>
</div>

<?php displayMenu(MYPROFILE);?>
<div id="content">

    <?php
    if (isset($_GET["err"])) {
        $err = $_GET["err"];
        echo "<h2>Form Error</h2>";
        echo "<p>There was a problem with your submission:";
        echo "<blockquote><p><b>";

    if ($err == "missingdata") {
            echo "You did not provide all of the required information";
    }
    else if($err == "passmatch"){
            echo "Your password do not match";
    }
    else if($err == "nocon"){
        echo "Cannot connect to the data base";
    }
    echo "</b></blockquote><p>Please try again!";
    }
    else {

        echo "<p>Welcome to the Central Scotland College";

        echo "<p>We hope you will take part in activities we offer!";
    }
    ?>
    <form action="processChange.php" method="post">
        Password:<input type="password" name="password"><br>
        Confirm password:<input type="password" name="passwordCheck"><br>

        <input type="submit" value="Change password">

    </form>
    <p style="font-weight: bold">Click here to delete your account</p>

    <form action="deleteAccount.php">
        <button type="submit">Delete</button>
    </form>

</div>
</body>
</html>