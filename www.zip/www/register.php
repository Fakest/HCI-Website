<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: Harry
 * Date: 25/05/2019
 * Time: 13:44
 */
require 'menu.php';
require 'login.php';
?>
<!--
This pages purpose is to be accept user details in a text box and validate them. Once they have been validated the user will be added to the data base.
The page will report any problems with the registration entries.
-->
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/menu.css">

    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <style>
        h2{
            color: red;
            font-weight: bold;
            text-align: center;
        }
        p{
            color: black;
            text-align: center;
        }
    </style>

    <script type="text/javascript">
        function displayError(msg) {
            alert("Problem signing in: "+msg);
        }
    </script>
    <script src="js/menu.js" type="text/javascript"></script>

    <meta charset="UTF-8">
    <meta name="description" content="Central Scotland College's registration page.">
    <meta name="keywords" content="Central Scotland College, Register, User, Credentials">
    <meta name="author" content="Harry Beggs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="header">
    <img src="img/logo.jpg" id="logo">
    <h1>Register</h1>
    <?php displayLogin();?>
    <script src="js/validateRegForm.js" type="text/javascript"></script>
</div>
<?php displayMenu(HOME);?>
<div id="content">
    <?php
    if (isset($_GET["err"])) {
        $err = $_GET["err"];
        echo "<h2>Form Error</h2>";
        echo "<p>There was a problem with your submission:";
        echo "<blockquote><p><b>";
        if ($err == "idformat") {
            echo "Your id was in the wrong format";
        }
        else if ($err == "missingdata") {
            echo "You did not provide all of the required information";
        }
        else if($err == "passmatch"){
            echo "Your password do not match";
        }
        else if($err == "idused"){
            echo "The id you entered is already registered!";
        }
        echo "</b></blockquote><p>Please try again!";
    }
    else {
        echo "<h1>Welcome</h1>";

        echo "<p>Welcome to the Central Scotland College";

        echo "<p>We hope you will take part in activities we offer!";
    }
    ?>
    <form action="processReg.php" name="registration" onsubmit="return validateRegForm('registration')" method="post">
        Full name: <input type="text" name="fullName"><br>
        Student id:<input type="text" name="studentId"><br>
        Email:<input type="text" name="email"><br>
        Password:<input type="password" name="password"><br>
        Confirm password:<input type="password" name="passwordCheck"><br>

        <input type="submit" value="Register">

    </form>
</div>
</body>
</html>