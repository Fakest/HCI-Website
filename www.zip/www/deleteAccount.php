<?php
/**
 * Created by PhpStorm.
 * User: 555340
 * Date: 14/06/2019
 * Time: 11:59
 */

require 'userSession.php';
require 'database.php';

//Check that there is a user signed in and delete their account from the data base backend

if(!connectToDb('csc_backend')){

    $_SESSION['errorMsg'] = "Sorry we could not connect to the data base";
    header('location:register.php');
    exit();
}
$userId = $_SESSION['userId'];

if($userId == ''){

    $_SESSION['errorMsg'] = "Cannot get user id";
    header('location:register.php');
    exit();
}
//$userId = sanitizeString($userId);

$sql = "DELETE FROM students  WHERE  id  =  " . $userId;
$result = $dbConnection->query($sql);

if(!$result){
    $_SESSION['errorMsg'] = "Error deleting record: " . $dbConnection->error;
}
$dbConnection.closeConnection();
session_destroy();
header('location:index.php');
?>