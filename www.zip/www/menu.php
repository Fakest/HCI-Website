<?php

/* Constants defining the top level menu items in the site
   Note that the numerical values of these constants need to
   match up with the menuItems array defined in the displayMenu
   function.
*/
const HOME = 0;
const ACTIVITIES = 1;
const ABOUT = 2;
const MYPROFILE = 3;

// Display the menu in a page.

function displayMenu($section)
{
	// the top level menu items are stored as an array
	$menuItems = array(' href="index.php">Home',
					   ' href="activities.php">Activities',
					   ' href="about.php">About',
					   ' href="profile.php">My Profile',
                        ' href="#" class="icon" id="menuicon" onclick="toggleClass(\'topnav\', \'menuicon\')"><b>&equiv;</b>'); //this link is to display a drop down button that the user can click when the screen is below a certian size.
	
	// write the opening structure of the menu

    echo '<div id="topnav" class="menu">';
    // write the individual menu items
    $menuCount = count($menuItems);
    for ($i = 0; $i < $menuCount; $i++) {
        echo "\n<a";
        if ($section == $i) { // if an item is selected, add the correct class spec
            echo " class='selected'";
        }
        echo  $menuItems[$i] . "</a>";
    }

    // write the closing structure of the menu
    echo "\n
		</div>";
}

?>