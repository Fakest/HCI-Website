<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: Harry
 * Date: 25/05/2019
 * Time: 13:44
 */
require 'menu.php';
require 'login.php';
require 'userSession.php';
?>
<!--
    This page will welcome the user and show them the central scotland college preview video.
    All pages will allow the user to register or sign in to the website.
-->
<html>

<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/menu.css">

    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <script type="text/javascript">
        function displayError(msg) {
            alert("Problem signing in: "+msg);
        }
    </script>
    <script src="js/menu.js" type="text/javascript"></script>
    <meta charset="UTF-8">
    <meta name="description" content="Central Scotland College's about page.">
    <meta name="keywords" content="Central Scotland College, About, Contact Details">
    <meta name="author" content="Harry Beggs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body

    <?php
    // check for a sign in error and post an alert if necessary
    $errMsg = null;
    if (isset($_SESSION['errorMsg'])) {
        $errMsg = $_SESSION['errorMsg'];
        echo ' onload="displayError(\''.$errMsg.'\')"';
    }
    ?>
>
<div id="header">
    <img src="img/logo.jpg" id="logo">
    <h1>Home</h1>
    <?php displayLogin();?>
</div>
    <?php displayMenu(HOME);?>

<div id="content">

    <h2>
        Welcome to Central Scotland College!
    </h2>
    <iframe id="vid1" src="https://www.youtube.com/embed/XQLdhVpLBVE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

    <p>
        Welcome to the Central Scotland College web page! Here you can sign up for extracurricular activities and manage the activities you have already subscribed to.
    </p>
</div>

</body>


</html>
