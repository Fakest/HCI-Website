<?php

/*
	Process a sign in request, checking a user's password.
    Also checking that the users id matches the regular expression
*/

require 'database.php';

ini_set('session.use_strict_mode', 1);
session_start();

// if there is an existing session user, remove it
if (isset($_SESSION['studentId'])) {
    unset($_SESSION['studentId']);
}

// unset any previous error message
if(isset($_SESSION['errorMsg'])){
    unset($_SESSION['errorMsg']);
}

// check the form contains all the post data
if (!(isset($_POST['studentId']) &&
    isset($_POST['psw']))) {
    header('location:index.php');
    exit();
}


// recover the form data
$userId = trim($_POST['studentId']);
$password = trim($_POST['psw']);

// validate the id
if (!preg_match('/^[0-9]{1,6}$/', $userId)) {
    $_SESSION['errorMsg'] = "Unexpectedly illegal id!";

    header('location:index.php');

    exit();
}

// connect to the database
if (!connectToDb('csc_backend')) {
    $_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
    header('location:index.php');
    exit();
}

// after this point we have an open DB connection

// check
$userId = sanitizeString($userId);
$sqlQuery = "SELECT password FROM students WHERE id='$userId'";
$result = $dbConnection->query($sqlQuery);
if ($result->num_rows != 1) {
    closeConnection();
    if ($result->num_rows == 0) {
        $_SESSION['errorMsg'] = "User id not recognized";
    }
    else {
        $_SESSION['errorMsg'] = "Sorry - unexpected problem with the database";
    }
    header('location:index.php');
    exit();
}

// get the expected answer from the db
$row = $result->fetch_assoc();
$pwHash = $row['password'];
closeConnection();

// check the supplied answer is correct
if (!password_verify($password, $pwHash)) {
    $_SESSION['errorMsg'] = "Incorrect password! Please try again...";
}
else {
    $_SESSION['userId'] = $userId;
    unset($_SESSION['signInErr']);
}

// everything worked, update the session info

header('Location:index.php');

?>