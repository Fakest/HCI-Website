<!DOCTYPE html>
<?php
/**
 * Created by PhpStorm.
 * User: Harry
 * Date: 25/05/2019
 * Time: 18:26
 */

require 'menu.php';
require 'login.php';
require 'userSession.php';
?>

<!--
This pages purpose is to allow the users of the website view the activities available and allow the users to book the activities at a specified time
-->
<html>
<head>
    <title>Activities</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/menu.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

    <script type="text/javascript">
        function displayError(msg) {
            alert("Problem signing in: "+msg);
        }
    </script>
    <script src="js/menu.js" type="text/javascript"></script>

    <meta charset="UTF-8">
    <meta name="description" content="Central Scotland College's activity.">
    <meta name="keywords" content="Central Scotland College, Activities, Register">
    <meta name="author" content="Harry Beggs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="header">
    <img src="img/logo.jpg" id="logo">
    <h1>Activities</h1>
    <?php displayLogin();?>

</div>

<?php displayMenu(ACTIVITIES);?>
<div id="content">
    <table>
        <tr><th>Images</th><th>Activity</th><th>Date</th><th>Register</th></tr>
        <tr><td><img src="img/band.jpg" class="tableimg"> </td><td>Music</td><td><form><input type="date" value="2019-01-01" name="musicDate"</form></td><td><input type="button" value="Register" ></td></tr>
        <tr><td><img src="img/rugby.jpg" class="tableimg"></td><td>Rugby</td><td><form><input type="date" value="2019-01-01" name="rugbyDate"</form></td><td><input type="button" value="Register" name="rugby"></td></tr>
        <tr><td><img src="img/gloves.jpg" class="tableimg"></td><td>Boxing</td><td><form><input type="date" value="2019-01-01" name ="boxingDate"</form></td><td><input type="button" value="Register" name="boxing"></td></tr>
    </table>
</div>
</body>
</html>
