<?php
/**
 * Created by PhpStorm.
 * User: 555340
 * Date: 14/06/2019
 * Time: 12:28
 */
//process changes made to the users password and validate input.
require 'database.php';
require 'userSession.php';

if(empty($_POST['password']) ||
    empty($_POST['passwordCheck'])) {
    header('location:profile.php?err=missingdata');
    exit();
}

if($_POST['password'] != $_POST['passwordCheck']){
    header('location:profile.php?err=passmatch');
    exit();
}


if(!connectToDb('csc_backend')){
    $_SESSION['errorMsg'] = "Sorry we could not connect to the data base";
    header('location:profile.php');
    exit();
}

$password = $_POST['password'];

$password = sanitizeString($password);

$pwHash = password_hash($password, PASSWORD_BCRYPT);
$userId = $_SESSION['userId'];

$sqlQuery = "UPDATE students SET password = '$pwHash' WHERE id = '$userId'";


if($dbConnection->query($sqlQuery) === TRUE){
    echo "Record updated";
} else {
    echo "Error updating record: " . $dbConnection->error;
}

header('location:profile.php');
?>

