<?php
//this is the php function that prints the log in button and register hyperlink or the sign in button if appropriate
function displayLogin()
{
    global $userId;

    if ($userId == ''){
        echo "<div id=\"login\">
        <form action=\"processSignIn.php\" method=\"post\">

            <div class=\"container\">
                <label for=\"studentid\"><b>Student Id</b></label>
                <input type=\"text\" placeholder=\"Enter Student Id\" name=\"studentId\" required>

                <label for=\"psw\"><b>Password</b></label>
                <input type=\"password\" placeholder=\"Enter Password\" name=\"psw\" required>

                <button type=\"submit\">Login</button>
                <label>
            </div>

            <div class=\"container\";>
                <span class=\"psw\">Register <a href='register.php'>here</a></span>
            </div>
        </form>
    </div>";
    }
    else{

        echo '<div style="float: right"><span id="signout"><form action="signOut.php" method="post">Welcome ' . $userId . ' <input type="submit" value="Sign Out"></form></span></div>';
    }

}
?>