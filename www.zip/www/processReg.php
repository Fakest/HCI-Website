<?php
/**
 * Created by PhpStorm.
 * User: 555340
 * Date: 12/06/2019
 * Time: 11:45
 */

//this pages purpose is to process the user details and add them to the backend database.
//it will validate the data that has been entered and carry out appropriate actions when poor data is entered.

ini_set('session.use_strict_mode', 1);
session_start();

require 'database.php';

if(isset($_SESSION['id'])){
    unset($_SESSION['id']);
}

unset($_SESSION['errorMsg']);

if(!isset($_POST['fullName']) &&
    !isset($_POST['studentId']) &&
    !isset($_POST['email']) &&
    !isset($_POST['password']) &&
    !isset($_POST['passwordCheck'])) {
    header('location:register.php');
    exit();
}

$fullName = trim($_POST['fullName']);
$userId = trim($_POST['studentId']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);

if(empty($_POST['fullName']) ||
    empty($_POST['studentId']) ||
    empty($_POST['email']) ||
    empty($_POST['password']) ||
    empty($_POST['passwordCheck'])) {
    header('location:register.php?err=missingdata');
    exit();
}

if($_POST['password'] != $_POST['passwordCheck']){
    header('location:register.php?err=passmatch');
    exit();
}

if(!preg_match('/^[0-9]{1,6}$/', $userId)){
    header('location:register.php?err=idformat');
    exit();
}

if(!connectToDb('csc_backend')){
    $_SESSION['errorMsg'] = "Sorry we could not connect to the data base";
    header('location:register.php');
    exit();
}

$userId = sanitizeString($userId);
$sqlQuery = "SELECT * FROM students WHERE id = '$userId'";
$result = $dbConnection->query($sqlQuery);
if($result->num_rows > 0){
    closeConnection();
    header('location:register.php?err=idused');
    exit();
}

$fullName = sanitizeString($fullName);
$userId = sanitizeString($userId);
$email = sanitizeString($email);
$pwHash = password_hash($password, PASSWORD_BCRYPT);

$sqlQuery = "INSERT INTO students (id, name, email, password) VALUES ('$userId', '$fullName', '$email', '$pwHash')";

$result = $dbConnection->query($sqlQuery);
if(!$result){
    $_SESSION['errorMsg'] = "There was a problem with this operation: " .$dbConnection->error;
    closeConnection();
    header('location:register.php');
    exit();
}

closeConnection();
$_SESSION['fullName'] = $fullName;
header('location:index.php');

?>