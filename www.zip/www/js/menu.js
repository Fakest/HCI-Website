
/* Toggle between adding and removing the "responsive" class to the requested 
   element when the user clicks on the icon.

	@param elemId the ID of the element to modify.
*/
function toggleClass(menuId, iconId) 
{
    var menuElem = document.getElementById(menuId);
	
	if (menuElem != null) {
		if (menuElem.className === "menu") {
            menuElem.classList.add('responsive');
		}
		else {
			menuElem.className = "menu";
		}
	}
}