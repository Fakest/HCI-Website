/*
	A JS function for validating the username in the signin form.
	
	Author: Andreas Schoter
*/
function validateRegForm(formName)
{
	"use strict";

	// a username begins with an uppercase letter and consists of letters
	
	var emailRegex = /^[a-zA-Z0-9.!#$%&*+/=?^_{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

	// get the form from the DOM
	var form = document.forms[formName];
	
	// get the form data and trim leading & trailing whitespace
	var emailAdd = form["email"].value.trim();
	
	// validate the pattern of characters
	if (!emailRegex.test(emailAdd)) {
		alert("This is not a valid email address");
		form["email"].focus();
		return false;
	}
	
	// everything was ok
	return true;
}
